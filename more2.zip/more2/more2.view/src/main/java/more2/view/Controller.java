package more2.view;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import more2.persist.model.dao.finers.FindersDAO;
import more2.persist.model.dao.finers.FindersDAOImpl;
import more2.persist.model.domain.Escuela;
import more2.service.FinderDAOService;
import more2.service.FinderDAOServiceImpl;
import more2.service.ServiceEscuelaDAO;
import more2.service.ServiceEscuelaDAOImpl;



@RestController
public class Controller {

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();
    
    private static final FinderDAOService finderDAOService = new FinderDAOServiceImpl();
    private static final ServiceEscuelaDAO serviceEscuelaDAO = new ServiceEscuelaDAOImpl();
    
    @RequestMapping("/greeting")
    public Greeting greeting(@RequestParam(value="name", defaultValue="World") String name) {
        return new Greeting(counter.incrementAndGet(),
                            String.format(template, name));
    }
    
    @RequestMapping("/saludo")
    public Greeting saludo(@RequestParam(value="name", defaultValue="mundo") String name) {
        return new Greeting(counter.incrementAndGet(),
                            String.format(template, name));
    }
    
    @RequestMapping(value="/escuela", method = RequestMethod.GET)
    public Escuela getEscuela(@RequestParam(value="name") String name) {
    	
    	Escuela escuela = finderDAOService.findEscuelaByName(name);
    	return escuela;
    }
    
    @RequestMapping(value="/updateEscuela", method = RequestMethod.POST)
    public boolean updateEscuela(@RequestParam(value="name") String name, @RequestParam(value="newName")String newName){
    	Escuela escuela = finderDAOService.findEscuelaByName(name);
    	return serviceEscuelaDAO.update(escuela);
    }
    
    @RequestMapping(value="/delete", method = RequestMethod.DELETE)
    public boolean delete(@RequestParam(value="name") String name){
    	Escuela escuela = (Escuela) serviceEscuelaDAO.delete(finderDAOService.findEscuelaByName(name));
    	if (escuela!=null)
    		return true;
    	else
    		return false;
    }
    
    @RequestMapping(value="/createEscuela", method = RequestMethod.PUT)
    public boolean createEscuela(@RequestParam(value="name") String name){
    	Escuela escuela = (Escuela) serviceEscuelaDAO.saveUpdate(new Escuela(name, null));
    	if (escuela!=null)
    		return true;
    	else
    		return false;
    }
}