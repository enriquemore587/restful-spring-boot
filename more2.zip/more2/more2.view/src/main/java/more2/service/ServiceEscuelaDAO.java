package more2.service;


public interface ServiceEscuelaDAO {
	public Object saveUpdate(Object klass);
	public Object delete(Object klass);
	public boolean update(Object klass);
}
