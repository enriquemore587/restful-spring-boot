package more2.service;

import org.springframework.stereotype.Service;

import more2.persist.model.domain.Escuela;

@Service
public interface FinderDAOService {
	public Escuela findEscuelaByName(String name);
}
