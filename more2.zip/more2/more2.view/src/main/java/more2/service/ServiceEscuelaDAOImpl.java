package more2.service;

import more2.persist.model.dao.EscuelaDAO;
import more2.persist.model.dao.EscuelaDAOImpl;

public class ServiceEscuelaDAOImpl implements ServiceEscuelaDAO {

	private EscuelaDAO escuelaDAO = new EscuelaDAOImpl();
	
	public Object delete(Object klass) {
		return escuelaDAO.delete(klass);
	}

	public boolean update(Object klass) {
		return escuelaDAO.update(klass);
	}

	public Object saveUpdate(Object klass) {
		return escuelaDAO.saveUpdate(klass);
	}

}
