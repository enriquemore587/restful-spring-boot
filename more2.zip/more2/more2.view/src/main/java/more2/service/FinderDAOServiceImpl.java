package more2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import more2.persist.model.dao.finers.FindersDAO;
import more2.persist.model.dao.finers.FindersDAOImpl;
import more2.persist.model.domain.Escuela;

@Service
@Transactional
public class FinderDAOServiceImpl implements FinderDAOService, FindersDAO {
	
	private FindersDAO findersDAO = new FindersDAOImpl();

	public Escuela findEscuelaByName(String name) {
		return findersDAO.findEscuelaByName(name);
	}

}
