package more2.persist.test.escuela;

import java.util.ArrayList;
import java.util.List;

import more2.persist.model.dao.EscuelaDAO;
import more2.persist.model.dao.EscuelaDAOImpl;
import more2.persist.model.dao.finers.FindersDAO;
import more2.persist.model.dao.finers.FindersDAOImpl;
import more2.persist.model.domain.Escuela;
import more2.persist.model.domain.Estudiante;

public class TestEscuela {
	
	
	
	
	public static void main(String[] args) {
		(new TestEscuela()).newEscuela();
//		(new TestEscuela()).findEscuela("TESE");
	}
	
	public void newEscuela() {
		EscuelaDAO escuelaDAO = new EscuelaDAOImpl();
		
		Escuela escuela = new Escuela();
			escuela.setNombre("TESE");
				List<Estudiante> list = new ArrayList<Estudiante>();
				list.add(new Estudiante());
					list.get(0).setEscuela(escuela);
					list.get(0).setNombre("JOSE ENRIQUE");
					list.get(0).setPaterno("VERGARA");
			escuela.setEstudiante(list);
			
		escuela = (Escuela) escuelaDAO.saveUpdate(escuela);
		
		
		System.out.println("***************************\n"+escuela.getId());
		
		
	}
	
	public void findEscuela(String name){
		FindersDAO findersDAO = new FindersDAOImpl();
		Escuela escuela = findersDAO.findEscuelaByName(name);
		System.out.println("***************************\n"+escuela.getId());
	}
}
