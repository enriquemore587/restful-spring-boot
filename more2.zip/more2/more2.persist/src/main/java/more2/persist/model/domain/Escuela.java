package more2.persist.model.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


@Entity
@Table(name="escuela", catalog="baseTest")
public class Escuela implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1891331836437906020L;
	
	public Escuela() {
		// TODO Auto-generated constructor stub
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@Column(name="nombreEscuela")
	private String nombre;
	
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL, mappedBy="escuela",orphanRemoval=true)
	@Fetch(value=FetchMode.SUBSELECT)
	private List<Estudiante> Estudiante;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Estudiante> getEstudiante() {
		return Estudiante;
	}

	public void setEstudiante(List<Estudiante> estudiante) {
		Estudiante = estudiante;
	}

	public Escuela(String nombre, List<more2.persist.model.domain.Estudiante> estudiante) {
		super();
		this.nombre = nombre;
		Estudiante = estudiante;
	}
	
	
	
}
