package more2.persist.model.dao.finers;

import more2.persist.model.domain.Escuela;

public interface FindersDAO {
	public Escuela findEscuelaByName(String name);
}
