package more2.persist.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import more2.persist.model.domain.Escuela;
import more2.persist.model.domain.Estudiante;
import more2.persist.model.service.HibernateUtil;

@Repository
public class EscuelaDAOImpl implements EscuelaDAO {

	private static final Logger LOG = Logger.getLogger(EscuelaDAOImpl.class.getName());
	public static void main(String[] args) {
		Escuela escuela = new Escuela();
		escuela.setNombre("TESE");
			List<Estudiante> list = new ArrayList<Estudiante>();
			list.add(new Estudiante());
				list.get(0).setEscuela(escuela);
				list.get(0).setNombre("JOSE ENRIQUE");
				list.get(0).setPaterno("VERGARA");
		escuela.setEstudiante(list);
		
	escuela = (Escuela) (new EscuelaDAOImpl()).saveUpdate(escuela);
	
	
	LOG.log(Level.INFO,"***************************\n"+escuela.getId());
	}
	
	public Object saveUpdate(Object klass) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(klass);
			session.getTransaction().commit();
			session.close();
			LOG.log(Level.INFO, "Object saved. . .");
			
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Error at save. . .");
			session.getTransaction().rollback();
			session.close();
			return null;
		}
		return klass;
	}

	public Object delete(Object klass) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.delete(klass);
			session.getTransaction().commit();
			session.close();
			LOG.log(Level.INFO, "Object deleted. . .");
			return klass;
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Error at delete. . .");
			session.getTransaction().rollback();
			session.close();
			return null;
		}
	}

	public boolean update(Object klass) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.update(klass);
			session.getTransaction().commit();
			session.close();
			LOG.log(Level.INFO, "Object updated. . .");
			return true;
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Error at update. . .");
			session.getTransaction().rollback();
			session.close();
			return false;
		}
	}

}
