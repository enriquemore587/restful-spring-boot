package more2.persist.model.dao;

public interface EscuelaDAO {
	public Object saveUpdate(Object klass);
	public Object delete(Object klass);
	public boolean update(Object klass);
}
