package more2.persist.model.dao.finers;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import more2.persist.model.domain.Escuela;
import more2.persist.model.service.HibernateUtil;

@Repository
public class FindersDAOImpl implements FindersDAO {
//	private static final Logger LOG = Logger.getLogger(FindersDAOImpl.class.getName());
	
	
	public Escuela findEscuelaByName(String name) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Escuela escuela = null;
		try {
			
			Criteria criteria = session.createCriteria(Escuela.class)
					.add(Restrictions.eq("nombre", name))
					.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			
			escuela = (Escuela) criteria.uniqueResult();
			
			
			
//			LOG.log(Level.INFO, String.format("Escuela: %s encontrada.", escuela.getNombre()));
			
		} catch (Exception e) {
//			LOG.log(Level.ERROR, String.format("Escuela: %s NO encontrada.", escuela.getNombre()));
			
			
		}
		session.close();
		return escuela;
	}

}
